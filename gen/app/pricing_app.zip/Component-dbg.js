sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("pricing_app.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);